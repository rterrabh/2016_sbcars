package com.mywm.model.dao;

@SuppressWarnings("serial")
public class DAOException extends RuntimeException {
	
	private final Exception originalException;

	public DAOException(Exception ex) {
		this.originalException = ex;
	}
	
	@Override
	public String getMessage() {
		return this.originalException.getMessage();
	}
	
	@Override
	public void printStackTrace() {
		this.originalException.printStackTrace();
	}
}
