package com.mywm.model.dao.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.mywm.model.dao.DAOException;
import com.mywm.model.dao.IProductDAO;
import com.mywm.model.dto.Product;

public class ProductHibernateDAO implements IProductDAO {

	// from:ProductAction.find()
	public List<Product> find(Product product) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		Criteria criteria = sess.createCriteria(Product.class); // f:hibernate

		criteria.add(Example.create(product).excludeZeroes().ignoreCase()
				.enableLike(MatchMode.ANYWHERE)); // f:hibernate
		if (product.getId() != null) { // f:hibernate
			criteria.add(Restrictions.idEq(product.getId())); // f:hibernate
		} // f:hibernate

		@SuppressWarnings("unchecked")
		List<Product> l = (List<Product>) criteria.list(); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
		return l;
	}

	// from:ProductAction.save()
	public void save(Product product) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		sess.save(product); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
	}

	// from:ProductAction.update()
	public void update(Product product) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		sess.update(product); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
	}

	// from:ProductAction.delete()
	public void delete(Product product) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		sess.delete(product); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
	}

	// from:ProductAction.edit()
	public Product findByPK(Integer id) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		Product p = (Product) sess.get(Product.class, id); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
		return p;
	}

	// from:PurchaseOrderAction.input()
	public List<Product> findAll() throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate
		Criteria criteria = sess.createCriteria(Product.class); // f:hibernate
		@SuppressWarnings("unchecked")
		List<Product> lp = (List<Product>) criteria.list(); // f:hibernate
		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
		return lp;
	}

	// from:PurchaseOrderAjax.getProductPrice()
	public Double getPriceByProductId(Integer idProduct) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		Criteria criteria = sess.createCriteria(Product.class); // f:hibernate

		criteria.setProjection(Projections.property("price")); // f:hibernate

		criteria.add(Restrictions.eq("id", idProduct)); // f:hibernate

		Double price = (Double) criteria.uniqueResult(); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
		return price;
	}

	public List<Product> findProductsWithLowSupply() throws DAOException {
		org.hibernate.Session sess = HibernateUtil.getSessionFactory()
				.openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		Criteria criteria = sess.createCriteria(Product.class); // f:hibernate
		criteria.add(Restrictions.lt("supply", 5)); // f:hibernate

		@SuppressWarnings("unchecked")
		List<Product> l = (List<Product>) criteria.list(); // f:hibernate
		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
		return l;
	}

	// from:ReportAction.productReport()
	public List<Object[]> findToReport() throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		Criteria criteria = sess.createCriteria(Product.class); // f:hibernate

		criteria.setProjection(Projections.projectionList()
				.add(Projections.property("id"))
				.add(Projections.property("name"))
				.add(Projections.property("price"))); // f:hibernate

		@SuppressWarnings("unchecked")
		List<Object[]> l = (List<Object[]>) criteria.list(); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
		return l;
	}

}
