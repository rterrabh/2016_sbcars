package com.mywm.model.dao;

import java.util.List;

import com.mywm.model.dto.PurchaseOrder;


public interface IPurchaseOrderDAO {	
	
	public List<PurchaseOrder> find(PurchaseOrder purchaseOrder) throws DAOException;

	public void save(PurchaseOrder purchaseOrder) throws DAOException;

	public void update(PurchaseOrder purchaseOrder) throws DAOException;
	
	public void delete(PurchaseOrder purchaseOrder) throws DAOException;
	
	public PurchaseOrder findByPK( Integer id ) throws DAOException;
	
}
