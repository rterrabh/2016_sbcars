/*
 * $Id: Login.java 471756 2006-11-06 15:01:43Z husted $
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package com.mywm.controller.actions;


import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.ParameterAware;
import org.apache.struts2.interceptor.RequestAware;

import com.mywm.model.dao.hibernate.FactoryHibernate;
import com.mywm.model.dto.Customer;
import com.mywm.model.dto.Product;
import com.mywm.model.dto.PurchaseOrder;
import com.mywm.model.dto.PurchaseOrderItem;
import com.mywm.util.SystemConstants;
import com.opensymphony.xwork2.ActionContext;

@SuppressWarnings("serial")
public class PurchaseOrderAction extends ExampleSupport implements
		RequestAware, ParameterAware {
	private static Logger logger = Logger.getLogger(PurchaseOrderAction.class); //f:log
	private Map<String, Object> request;
	private Map<String, String[]> parameters;
	private PurchaseOrder purchaseOrder;
	private String task;
	
	@Override
	public void setRequest( Map<String, Object> map ) {
		request = map;
	}

	@Override
	public void setParameters( Map<String, String[]> parameters ) {
		this.parameters = parameters;

	}

	public PurchaseOrder getPurchaseOrder() {
		return this.purchaseOrder;
	}

	public void setPurchaseOrder( PurchaseOrder purchaseOrder ) {
		this.purchaseOrder = purchaseOrder;
	}

	public String getTask() {
		return this.task;
	}

	public void setTask( String task ) {
		this.task = task;
	}

	@Override
	public String execute() throws Exception {
		return this.input();
	}

	@Override
	public String input() throws Exception {
		logger.info( "Starting input()" ); //f:log
		this.task = SystemConstants.CR_MODE;

		this.purchaseOrder = null;

		List<Customer> lc = FactoryHibernate.getCustomerDAO().findAll();
		ActionContext.getContext().getSession().put( "listCustomer", lc );

		List<Product> lp = FactoryHibernate.getProductDAO().findAll();
		ActionContext.getContext().getSession().put( "listProduct", lp );

		logger.info( "Finishing input()" ); //f:log
		return INPUT;
	}

	

	public String find() throws Exception {
		logger.info( "Starting find()" ); //f:log
		
		List<PurchaseOrder> l = FactoryHibernate.getPurchaseOrderDAO().find(this.purchaseOrder);
		
		request.put( "list", l );

		this.task = SystemConstants.CR_MODE;
		logger.info( "Finishing input()" ); //f:log
		return INPUT;
	}


	public String save() throws Exception {
		logger.info( "Starting save()" ); //f:log
		

		this.purchaseOrder.setOrderDate( new Date() ); 

		for (PurchaseOrderItem item : this.purchaseOrder.getPurchaseOrderItems()) {  
			item.setPurchaseOrder( this.purchaseOrder );
		}
		
		FactoryHibernate.getPurchaseOrderDAO().save(this.purchaseOrder);

		this.task = SystemConstants.UD_MODE;
		this.addActionMessage( this.getText( "saveSuccessful", new String[] { "order" } ) );

		logger.info( "Finishing save()" ); //f:log
		return INPUT;
	}


	public String update() throws Exception {
		logger.info( "Starting update()" ); //f:log
		
		for (PurchaseOrderItem item : this.purchaseOrder.getPurchaseOrderItems()){
			item.setPurchaseOrder( this.purchaseOrder );
		}
		
		FactoryHibernate.getPurchaseOrderDAO().update(this.purchaseOrder);

		this.task = SystemConstants.UD_MODE;
		this.addActionMessage( this.getText( "updateSuccessful", new String[] { "order" } ) );

		logger.info( "Finishing update()" ); //f:log
		return INPUT;
	}


	public String delete() throws Exception {
		logger.info( "Starting delete()" ); //f:log

		FactoryHibernate.getPurchaseOrderDAO().delete(this.purchaseOrder);

		this.task = SystemConstants.CR_MODE;
		this.addActionMessage( this.getText( "deleteSuccessful", new String[] { "order" } ) );
		logger.info( "Finishing delete()" ); //f:log
		return this.input();
	}


	public String edit() throws Exception {
		logger.info( "Starting edit()" ); //f:log
		Integer id = Integer.valueOf( this.parameters.get( "id" )[0] );

		PurchaseOrder po = FactoryHibernate.getPurchaseOrderDAO().findByPK( id );

		this.setPurchaseOrder( po );
		this.task = SystemConstants.UD_MODE;
		logger.info( "Finishing edit()" ); //f:log
		return INPUT;
	}


	@Override
	public void validate() {
		logger.info( "Starting validate()" ); //f:log
		super.validate();

		int i = 0;
		for ( Iterator<PurchaseOrderItem> it = this.purchaseOrder.getPurchaseOrderItems().iterator(); it.hasNext(); i++ ) {
			PurchaseOrderItem item = it.next();

			if ( item.getProduct().getId() != null || item.getPrice() != null 
					|| item.getQuantity() != null || i == 0 ) {
				if ( item.getProduct().getId() == null ) {
					this.addFieldError( "item" + i + "_product", getText( "requiredspecific", new String[] { "Product" } ) );
				}
				if ( item.getPrice() == null ) {
					this.addFieldError( "item" + i + "_price", getText( "requiredspecific", new String[] { "Price" } ) );
				}
				if ( item.getQuantity() == null ) {
					this.addFieldError( "item" + i + "_quantity", getText( "requiredspecific", new String[] { "Quantity" } ) );
				}
			} else {
				it.remove();
			}
		}
		logger.info( "Finishing validate()" ); //f:log
	}

}