package com.mywm.controller.schedule;

import com.mywm.controller.schedule.quartz.SupplySchedule;

public class FactorySchedule {
	private static ISchedule supplySchedule = null;

	public static ISchedule getSuppySchedule() {
		if (supplySchedule == null) {
			supplySchedule = new SupplySchedule();
		}
		return supplySchedule;
	}
}
