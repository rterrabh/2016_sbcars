package com.mywm.controller.schedule;

import java.text.ParseException;

import org.quartz.SchedulerException;

public interface ISchedule {

	Integer getTimeInterval() throws SchedulerException;
	
	void setTimeInterval(Integer timeInterval) throws SchedulerException, ParseException;
}
