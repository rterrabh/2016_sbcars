package com.mywm.controller.schedule.quartz;


import java.util.List;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.mywm.controller.mail.FactoryMail;
import com.mywm.controller.mail.IMail;
import com.mywm.model.dao.hibernate.FactoryHibernate;
import com.mywm.model.dto.Product;

public class SupplyMailJob implements Job {
	private static Logger logger = Logger.getLogger( SupplyMailJob.class ); //f:log
	private IMail mail1 = FactoryMail.getMail1();
	
	public void execute( JobExecutionContext context )
			throws JobExecutionException {
		logger.info( "Starting execute() in job" ); //f:log

		List<Product> l = FactoryHibernate.getProductDAO().findProductsWithLowSupply();

		if ( !l.isEmpty() ) {
			StringBuilder str = new StringBuilder();
			str.append( "The following products are getting over:\n" );

			for ( Product p : l ) {
				str.append( p.getName() + "\t\t" + p.getSupply() + "\n" );
			}
			
			mail1.defaultSend( str );
		}

		logger.info( "Finishing execute() in job" ); //f:log
	}

	

}
