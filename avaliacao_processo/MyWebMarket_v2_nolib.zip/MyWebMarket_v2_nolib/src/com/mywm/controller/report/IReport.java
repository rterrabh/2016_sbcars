package com.mywm.controller.report;

import java.io.InputStream;
import java.util.List;

import net.sf.jasperreports.engine.JRException;

public interface IReport {

	byte[] generateProductReport( List<Object[]> l, InputStream in ) throws JRException;

	byte[] generateCustomerReport( List<Object[]> l, InputStream in ) throws JRException;
}
