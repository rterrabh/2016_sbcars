package com.mywm.controller.ajax;


import org.apache.log4j.Logger;

import com.mywm.model.dao.hibernate.FactoryHibernate;

public class PurchaseOrderAjax {
	private static Logger logger = Logger.getLogger(PurchaseOrderAjax.class); //f:log
	
	public Double getProductPrice(Integer idProduct){
		logger.info( "Starting getProductPrice()" ); //f:log
		Double price = FactoryHibernate.getProductDAO().getPriceByProductId( idProduct );
		logger.info( "Finishing getProductPrice()" ); //f:log
		return price;
	}
	
	
}
