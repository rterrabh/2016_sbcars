package com.mywm.controller.schedule.quartz;

import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import java.text.ParseException;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import org.quartz.impl.StdSchedulerFactory;

import com.mywm.controller.schedule.ISchedule;



public class SupplySchedule implements ISchedule {

	//from:SchedulerAction.input()
	public Integer getTimeInterval() throws SchedulerException {
		SchedulerFactory sf = new StdSchedulerFactory(); //f:quartz
		Scheduler sc = sf.getScheduler(); //f:quartz

		JobDetail job = sc.getJobDetail( JobKey.jobKey( "supplyMailJob", "group" ) ); //f:quartz

		if ( job != null ) { //f:quartz
			return job.getJobDataMap().getIntValue( "timeInterval" ); //f:quartz
		} //f:quartz
		
		return null;
	}
	
	//from:SchedulerAction.schedule()
	public void setTimeInterval(Integer timeInterval) throws SchedulerException, ParseException {
		SchedulerFactory sf = new StdSchedulerFactory(); //f:quartz
		Scheduler sc = sf.getScheduler(); //f:quartz

		JobDetail job = sc.getJobDetail( JobKey.jobKey( "supplyMailJob", "group" ) ); //f:quartz

		if ( job != null ) { //f:quartz
			sc.deleteJob( JobKey.jobKey( "supplyMailJob", "group" ) ); //f:quartz
		} //f:quartz

		job = newJob( SupplyMailJob.class ).withIdentity( "supplyMailJob", "group" ).build(); //f:quartz
		job.getJobDataMap().put( "timeInterval", timeInterval ); //f:quartz

		Trigger trigger = newTrigger().withIdentity( "supplyMailTrigger", "group" ).startNow().withSchedule( CronScheduleBuilder.cronSchedule( "0 0/"
				+ (timeInterval * 60) + " * * * ?" ) ).build(); //f:quartz

		sc.scheduleJob( job, trigger ); //f:quartz
	}	
	
}
