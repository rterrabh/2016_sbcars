package com.mywm.controller.mail;

public interface IMail {
	public void defaultSend( StringBuilder str );
}
