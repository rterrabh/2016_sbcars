package com.mywm.controller.mail;

import com.mywm.controller.mail.javamail.JavaMail;

public class FactoryMail {
	public static IMail getMail1() {
		return new JavaMail();
	}
}
