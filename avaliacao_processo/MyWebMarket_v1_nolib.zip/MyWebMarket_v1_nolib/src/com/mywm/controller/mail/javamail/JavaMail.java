package com.mywm.controller.mail.javamail;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.mywm.controller.mail.IMail;


public class JavaMail implements IMail {
	private String to = "terra@dcc.ufmg.br";
	private String from = "terra@dcc.ufmg.br";
	private String host = "smtp.dcc.ufmg.br"; 
	
	
	public void defaultSend( StringBuilder str ) {
		Properties props = new Properties(); //f:mail
		props.setProperty( "mail.smtp.submitter", "terra" ); //f:mail
		props.setProperty( "mail.smtp.auth", "false" ); //f:mail
		props.setProperty( "mail.smtp.host", this.host ); //f:mail
		props.setProperty( "mail.smtp.port", "25" ); //f:mail

		javax.mail.Session session = javax.mail.Session.getInstance( props ); //f:mail
		
		try { //f:mail
			Message msg = new MimeMessage( session ); //f:mail

			msg.setFrom( new InternetAddress( this.from ) ); //f:mail
			InternetAddress[] address = { new InternetAddress( this.to ) }; //f:mail
			msg.setRecipients( Message.RecipientType.TO, address ); //f:mail
			msg.setSubject( "Low Supply of Products" ); //f:mail
			msg.setSentDate( new Date() ); //f:mail

			msg.setText( str.toString() ); //f:mail

			Transport.send( msg ); //f:mail
		} catch (MessagingException mex) { //f:mail
			mex.printStackTrace(); //f:mail
		} //f:mail
	}
}
