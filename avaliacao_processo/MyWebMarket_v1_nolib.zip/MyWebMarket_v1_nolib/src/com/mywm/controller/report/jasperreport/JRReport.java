package com.mywm.controller.report.jasperreport;


import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

import com.mywm.controller.report.IReport;
import com.mywm.model.dao.hibernate.HibernateQueryResultDataSource;

public class JRReport implements IReport {

	//from:ReportAction.productReport()
	public byte[] generateProductReport( List<Object[]> l, InputStream in ) throws JRException {
		JasperReport jasperReport = JasperCompileManager.compileReport( in ); //f:jr

		Map<String, Object> parameters = new HashMap<String, Object>(); //f:jr
		parameters.put( "ReportTitle", "List of Products" ); //f:jr
		parameters.put( "DataFile", new Date().toString() ); //f:jr

		HibernateQueryResultDataSource ds = new HibernateQueryResultDataSource(l, new String[] { "Id", "Name", "Price" }); //f:jr

		JasperPrint jasperPrint = JasperFillManager.fillReport( jasperReport, parameters, ds ); //f:jr

		byte b[] = JasperExportManager.exportReportToPdf( jasperPrint ); //f:jr
		return b;
	}
	
	//from:ReportAction.customerReport()
	public byte[] generateCustomerReport( List<Object[]> l, InputStream in ) throws JRException {
		JasperReport jasperReport = JasperCompileManager.compileReport( in ); //f:jr
		
		Map<String, Object> parameters = new HashMap<String, Object>(); //f:jr
		parameters.put( "ReportTitle", "List of Customers" ); //f:jr
		parameters.put( "DataFile", new Date().toString() ); //f:jr

		HibernateQueryResultDataSource ds = new HibernateQueryResultDataSource(l, new String[] { "Id", "Name", "Phone" }); //f:jr

		JasperPrint jasperPrint = JasperFillManager.fillReport( jasperReport, parameters, ds ); //f:jr

		byte b[] = JasperExportManager.exportReportToPdf( jasperPrint ); //f:jr
		return b;
	}
	
}
