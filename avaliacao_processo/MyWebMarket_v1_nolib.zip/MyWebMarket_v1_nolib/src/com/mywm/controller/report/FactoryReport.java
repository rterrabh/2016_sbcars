package com.mywm.controller.report;

import com.mywm.controller.report.jasperreport.JRReport;

public class FactoryReport {
	private static IReport jr = new JRReport();
	
	public static IReport getJr(){
		return jr;
	}
}
