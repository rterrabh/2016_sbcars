package com.mywm.util;

public interface SystemConstants {
	String AUTHENTICATED_USER = "authenticatedUser";
	
	String CR_MODE = "cr";
	String UD_MODE = "ud";
}
