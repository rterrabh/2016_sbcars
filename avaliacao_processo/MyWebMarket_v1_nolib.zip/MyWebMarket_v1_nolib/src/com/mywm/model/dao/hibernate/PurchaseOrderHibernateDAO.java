package com.mywm.model.dao.hibernate;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import com.mywm.model.dao.DAOException;
import com.mywm.model.dao.IPurchaseOrderDAO;
import com.mywm.model.dto.PurchaseOrder;


public class PurchaseOrderHibernateDAO implements IPurchaseOrderDAO {
	
	//from:PurchaseOrderAction.find()
	public List<PurchaseOrder> find(PurchaseOrder purchaseOrder) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); //f:hibernate
		Transaction t = sess.beginTransaction(); //f:hibernate

		Criteria criteria = sess.createCriteria( PurchaseOrder.class ); //f:hibernate

		criteria.add( Example.create( purchaseOrder ).excludeZeroes().ignoreCase().enableLike( MatchMode.ANYWHERE ) ); //f:hibernate
		if ( purchaseOrder.getId() != null ) { //f:hibernate
			criteria.add( Restrictions.idEq( purchaseOrder.getId() ) ); //f:hibernate
		} //f:hibernate

		if ( purchaseOrder.getCustomer().getId() != null ) { //f:hibernate
			criteria.add( Restrictions.eq( "customer", purchaseOrder.getCustomer() ) ); //f:hibernate
		} //f:hibernate

		criteria.setResultTransformer( Criteria.DISTINCT_ROOT_ENTITY ); //f:hibernate
		@SuppressWarnings("unchecked")
		List<PurchaseOrder> l = (List<PurchaseOrder>) criteria.list(); //f:hibernate
		
		t.commit(); //f:hibernate
		sess.close(); //f:hibernate
		return l;
	}
	
	//from:PurchaseOrderAction.save()
	public void save(PurchaseOrder purchaseOrder) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); //f:hibernate
		Transaction t = sess.beginTransaction(); //f:hibernate
		
		sess.save( purchaseOrder ); //f:hibernate

		t.commit(); //f:hibernate
		sess.close(); //f:hibernate
	}
	
	//from:PurchaseOrderAction.update()
	public void update(PurchaseOrder purchaseOrder) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); //f:hibernate
		Transaction t = sess.beginTransaction(); //f:hibernate

		sess.update( purchaseOrder ); //f:hibernate

		t.commit(); //f:hibernate
		sess.close(); //f:hibernate
	}


	//from:PurchaseOrderAction.delete()
	public void delete(PurchaseOrder purchaseOrder) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); //f:hibernate
		Transaction t = sess.beginTransaction(); //f:hibernate

		sess.delete( purchaseOrder ); //f:hibernate

		t.commit(); //f:hibernate
		sess.close(); //f:hibernate
	}
	

}
