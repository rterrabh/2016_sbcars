package com.mywm.model.dao.hibernate;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.mywm.model.dao.DAOException;
import com.mywm.model.dao.IUserDAO;
import com.mywm.model.dto.User;


public class UserHibernateDAO implements IUserDAO {

	//from:LoginAction.execute()
	public User findByExample(User userParam) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); //f:hibernate
		Transaction t = sess.beginTransaction(); //f:hibernate

		Criteria criteria = sess.createCriteria( User.class ); //f:hibernate

		criteria.add( Restrictions.idEq( userParam.getUsername() ) ); //f:hibernate
		criteria.add( Restrictions.eq( "password", userParam.getPassword() ) ); //f:hibernate

		User user = (User) criteria.uniqueResult(); //f:hibernate

		t.commit(); //f:hibernate
		sess.close(); //f:hibernate
		return user;
	}
	
}
