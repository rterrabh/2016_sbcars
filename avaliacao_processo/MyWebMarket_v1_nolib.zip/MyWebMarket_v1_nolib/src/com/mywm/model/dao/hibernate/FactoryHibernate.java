package com.mywm.model.dao.hibernate;

import com.mywm.model.dao.ICustomerDAO;
import com.mywm.model.dao.IProductDAO;
import com.mywm.model.dao.IPurchaseOrderDAO;
import com.mywm.model.dao.IUserDAO;
import com.mywm.model.dto.ProductHibernateDAO;

public class FactoryHibernate {
	private static ICustomerDAO customerDAO;
	private static IUserDAO userDAO;
	private static IProductDAO productDAO;
	private static IPurchaseOrderDAO purchaseOrderDAO;
	
	private FactoryHibernate(){}
	
	/*7 call sites*/
	public static ICustomerDAO getCustomerDAO(){
		if (customerDAO == null){
			customerDAO = new CustomerHibernateDAO(); 
		}
		return customerDAO;
	}
	
	/*1 call site*/
	public static IUserDAO getUserDAO(){
		if (userDAO == null){
			userDAO = new UserHibernateDAO(); 
		}
		return userDAO;
	}
	
	/*9 call sites*/
	public static IProductDAO getProductDAO(){
		if (productDAO == null){
			productDAO = new ProductHibernateDAO(); 
		}
		return productDAO;
	}
	
	/*5 call sites*/
	public static IPurchaseOrderDAO getPurchaseOrderDAO(){
		if (purchaseOrderDAO == null){
			purchaseOrderDAO = new PurchaseOrderHibernateDAO(); 
		}
		return purchaseOrderDAO;
	}
}
