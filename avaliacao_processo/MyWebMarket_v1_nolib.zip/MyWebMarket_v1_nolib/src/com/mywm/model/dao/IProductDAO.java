package com.mywm.model.dao;

import java.util.List;

import com.mywm.model.dto.Product;


public interface IProductDAO {

	public List<Product> find(Product product) throws DAOException;	

	public void save(Product product) throws DAOException;
	

	public void update(Product product) throws DAOException;
	

	public void delete(Product product) throws DAOException;
	

	public Product findByPK( Integer id ) throws DAOException;
	
	
	public List<Product> findAll() throws DAOException;
	
	
	public Double getPriceByProductId( Integer idProduct ) throws DAOException;
	
	public List<Product> findProductsWithLowSupply() throws DAOException;

	public List<Object[]> findToReport() throws DAOException;
	
}
