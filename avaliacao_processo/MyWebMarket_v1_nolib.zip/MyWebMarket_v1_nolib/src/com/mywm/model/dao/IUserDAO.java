package com.mywm.model.dao;

import com.mywm.model.dto.User;

public interface IUserDAO {
	public User findByExample(User userParam) throws DAOException ;
}
