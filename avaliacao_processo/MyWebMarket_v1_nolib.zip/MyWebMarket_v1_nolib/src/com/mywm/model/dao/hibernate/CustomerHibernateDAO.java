package com.mywm.model.dao.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.mywm.model.dao.DAOException;
import com.mywm.model.dao.ICustomerDAO;
import com.mywm.model.dto.Customer;

public class CustomerHibernateDAO implements ICustomerDAO {

	// from:CustomerAction.find()
	public List<Customer> find(Customer customer) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		Criteria criteria = sess.createCriteria(Customer.class); // f:hibernate

		criteria.add(Example.create(customer).excludeZeroes().ignoreCase()
				.enableLike(MatchMode.ANYWHERE)); // f:hibernate
		if (customer.getId() != null) { // f:hibernate
			criteria.add(Restrictions.idEq(customer.getId())); // f:hibernate
		} // f:hibernate

		@SuppressWarnings("unchecked")
		List<Customer> l = (List<Customer>) criteria.list(); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
		return l;
	}

	// from:CustomerAction.save()
	public void save(Customer customer) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		sess.save(customer); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
	}

	// from:CustomerAction.update()
	public void update(Customer customer) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		sess.update(customer); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
	}

	// from:CustomerAction.delete()
	public void delete(Customer customer) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		sess.delete(customer); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
	}

	// from:CustomerAction.edit()
	public Customer findByPK(Integer id) throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		Customer c = (Customer) sess.get(Customer.class, id); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
		return c;
	}

	// from:PurchaseOrderAction.input()
	public List<Customer> findAll() throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		Criteria criteria = sess.createCriteria(Customer.class); // f:hibernate
		@SuppressWarnings("unchecked")
		List<Customer> lc = (List<Customer>) criteria.list(); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
		return lc;
	}

	// from:ReportAction.customerReport()
	public List<Object[]> findToReport() throws DAOException {
		Session sess = HibernateUtil.getSessionFactory().openSession(); // f:hibernate
		Transaction t = sess.beginTransaction(); // f:hibernate

		Criteria criteria = sess.createCriteria(Customer.class); // f:hibernate

		criteria.setProjection(Projections.projectionList()
				.add(Projections.property("id"))
				.add(Projections.property("name"))
				.add(Projections.property("phone"))); // f:hibernate

		@SuppressWarnings("unchecked")
		List<Object[]> l = (List<Object[]>) criteria.list(); // f:hibernate

		t.commit(); // f:hibernate
		sess.close(); // f:hibernate
		return l;
	}
}
