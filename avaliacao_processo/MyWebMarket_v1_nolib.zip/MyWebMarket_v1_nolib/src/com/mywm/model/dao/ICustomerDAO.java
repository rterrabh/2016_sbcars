package com.mywm.model.dao;

import java.util.List;

import com.mywm.model.dto.Customer;


public interface ICustomerDAO {

	public List<Customer> find( Customer customer ) throws DAOException;

	public void save( Customer customer ) throws DAOException;

	public void update( Customer customer ) throws DAOException;

	public void delete( Customer customer ) throws DAOException;

	public Customer findByPK( Integer id ) throws DAOException;

	public List<Customer> findAll() throws DAOException;
	
	public List<Object[]> findToReport() throws DAOException;
}
